﻿/*时钟*/
function clock(){
  now = new Date();
  year = now.getFullYear();
  month = now.getMonth() + 1;
  day = now.getDate();
  today = ["星期日","星期一","星期二","星期三","星期四","星期五","星期六"];
  week = today[now.getDay()];
  hour = now.getHours();
  min = now.getMinutes();
  sec = now.getSeconds();
  month=month>9?month:"0"+month;
  day=day>9?day:"0"+day;
  hour=hour>9?hour:"0"+hour;
  min=min>9?min:"0"+min;
  sec=sec>9?sec:"0"+sec;
  $("#times").html(year + "-" + month + "-" + day + " " + hour + ":" + min + ":" + sec +" "+ week);
}
window.onload = function () {
	var a_idx = 0;
	$("body").click(function(e) {
		var a = new Array(
			"暴富", "多金", "变美", "变瘦",
			"发财", "+100", "+200", "+300",
			"+400", "+500", "+600", "+700"
			);
		var $i = $("<span/>").text(a[a_idx]);
		a_idx = (a_idx + 1) % a.length;
		var x = e.pageX,
		y = e.pageY;
		$i.css({
			"z-index": 144469,
			"top": y - 20,
			"left": x,
			"position": "absolute",
			"font-weight": "bold",
			"color": "#f00",
			"font-size": "18px"
		});
		$("body").append($i);
		$i.animate({
			"top": y - 180,
			"opacity": 0
		},
		1500,
		function() {
			$i.remove()
		})
	});
};
$(function () {
	$('body').on('click','[data-loading-text]',function(){
		$(this).button('loading').delay(1000).queue(function() {
			$(this).button('reset');
			$(this).dequeue();
		});
	});
	/*密码输入框显示隐藏*/
	$(".modal-body,form").on('click','#toggle-password',function(){
		if ($(this).prev().attr('type')=="password"){
			$(this).prev().attr('type','text');
			$(this).children().attr('class','glyphicon glyphicon-eye-close')
		}else{
			$(this).prev().attr('type','password');
			$(this).children().attr('class','glyphicon glyphicon-eye-open')
		}
	});
	$("[data-toggle='tooltip']").tooltip();
	/*模态框监测关闭后清除内容*/
	$('#myModal').on('hide.bs.modal', function () {
		$('.modal-title').html('');
		$('.modal-body').html('');
	})
	/*qq头像获取 同类插件复用*/
	$("#trash,#btnr").hide();//清除输入框按钮隐藏
	$("#input_data").bind("input propertychange keyup paste",function(event){
		if ($("#input_data").val().length>0){
			$("#trash,#btnr").fadeIn("3000");
		}else{
			$("#trash,#btnr").fadeOut("2000");
		}
	});
	/*输入框内容填充*/
	$("a#test_data").click(function(){
		$("#input_data").val($(this).text()).focus().trigger('input');//填充内容、聚焦、触发输入
		$("#trash,#btnr").fadeIn("3000");
	});
	/*输入框内容清除*/
	$("#trash").click(function(){
		$("#input_data").val("");
		$("#trash,#btnr").fadeOut("2000");
	});
//反选
	$('body').on('click','#chose',function(){
	    const dmo=$(this).attr('dom')
		$(`${dmo}`).each(function(){
			$(this).prop("checked", $(this).is(':checked')?false:true);
		})
		if ($(`${dmo}`).length==$(`${dmo}:checked`).length){
			$(`input#choseall`).prop("checked", true);
		}else{
			$(`input#choseall`).prop("checked", false);
		}
	})
//全选，取消
	$('body').on('click','#choseall',function(){
	    const dmo=$(this).attr('dom')
		if ($(`${dmo}`).length!=$(`${dmo}:checked`).length){
			$(`${dmo},input#choseall`).prop("checked", true);
		}else{
			$(`${dmo},input#choseall`).prop("checked", false);
		}
	})
	setInterval(clock,1000);
});