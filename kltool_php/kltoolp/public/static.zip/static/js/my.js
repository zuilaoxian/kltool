﻿/*时钟*/
function clock(){
  now = new Date();
  year = now.getFullYear();
  month = now.getMonth() + 1;
  day = now.getDate();
  today = ["星期日","星期一","星期二","星期三","星期四","星期五","星期六"];
  week = today[now.getDay()];
  hour = now.getHours();
  min = now.getMinutes();
  sec = now.getSeconds();
  month=month>9?month:"0"+month;
  day=day>9?day:"0"+day;
  hour=hour>9?hour:"0"+hour;
  min=min>9?min:"0"+min;
  sec=sec>9?sec:"0"+sec;
  $("#times").html(year + "-" + month + "-" + day + " " + hour + ":" + min + ":" + sec +" "+ week);
}
window.onload = function () {
	var a_idx = 0;
	$("body").click(function(e) {
		var a = new Array(
			"暴富", "多金", "变美", "变瘦",
			"发财", "+100", "+200", "+300",
			"+400", "+500", "+600", "+700"
			);
		var $i = $("<span/>").text(a[a_idx]);
		a_idx = (a_idx + 1) % a.length;
		var x = e.pageX,
		y = e.pageY;
		$i.css({
			"z-index": 144469,
			"top": y - 20,
			"left": x,
			"position": "absolute",
			"font-weight": "bold",
			"color": "#f00",
			"font-size": "18px"
		});
		$("body").append($i);
		$i.animate({
			"top": y - 180,
			"opacity": 0
		},
		1500,
		function() {
			$i.remove()
		})
	});
};
$(function () {
	/*bootstrap自带分页增强*/
	$('.pagination span:contains("...")').click(function(){
		var pid=$(this);
		var turl=location.search;
		if (location.search=="") turl+='?';
		var valuen='';
		var s=turl.split('?')[1].split('&');
		for(i=0;i<s.length;i++){
			value=s[i]
			if (value){
				values=value.split('=')
				if (values[0]!='page') valuen+='<input name="'+values[0]+'" value="'+decodeURI(values[1])+'" type="hidden">';
			}
		}
		valuen+='<input name="page" value="" type="text">';
		pid.html('<form action="'+location.pathname+'" method="get">'+valuen+'</form>');
		console.log(valuen);
		$('input[name=page]').focus();
		$('input[name=page]').blur(function(){
			pid.html('...');
		});
	})
	/*登入*/
	$("#navbar").on('click','a#login',function(){
		event.preventDefault();
		$('#myModalLabel').html('登录|注册');
		$('.modal-body').html('<ul id="myTab" class="nav nav-tabs"><li class="active"><a href="#login-tab1" data-toggle="tab" aria-expanded="true">登录</a></li><li class=""><a href="#reg-tab1" data-toggle="tab" aria-expanded="false">注册</a></li></ul><div class="form-group"><label for="name">用户名&密码：任意中英符号表情支持，长度4 - 30</label></div><form class="form-horizontal" role="form" id="login"><div class="form-group"><label for="username" class="col-sm-2 control-label">用户名</label><div class="col-sm-10"><input type="text" class="form-control" id="username" name="username" placeholder="" autocomplete="off"></div></div><div class="form-group"><label for="password" class="col-sm-2 control-label">密码</label><div class="col-sm-10"><div class="input-group"><input type="password" class="form-control" id="password" name="password" placeholder="" autocomplete="off"><span class="input-group-addon" id="toggle-password"><i class="glyphicon glyphicon-eye-open"></i></span></div></div></div><div id="myTabContent1" class="tab-content"><div class="tab-pane fade active in" id="login-tab1"><button type="button" id="login" action="login/login" class="btn btn-default btn-block" style="border-color:green;">登录</button></div><div class="tab-pane fade" id="reg-tab1"><div class="form-group"><label for="email" class="col-sm-2 control-label">邮箱</label><div class="col-sm-10"><input type="text" class="form-control" id="email" name="email" placeholder="注册时可选 登陆时不填" autocomplete="off"></div></div><button type="button" id="login" action="reg" class="btn btn-default btn-block" style="border-color: red;">注册</button></div></div></form>');
		$('#myModal').modal('show');
		login_click();
	})
	/*登出*/
	$("#navbar,.btn-inline-box2").on('click','a#logout',function(){
		event.preventDefault();
		layer.confirm('确定退出登录吗?', {
		  btn: ['确定','取消']
		  ,shadeClose:true
		  ,title:''
		}, function(){
			$.ajax({
			url:'/logout',
			type:'get',
			dataType :'json',
			async:true,
				success:function(data){
					layer.alert(
						data.msg,{closeBtn: 0
							,shadeClose:true
							,title:''
							,btn: ['关闭']
							,yes:function(){
								layer.closeAll();
								location.reload();
							}
						}
					);
				},
				error:function(xhr){
					layer.msg('错误：'+xhr.status+' '+xhr.statusText,{time: 3000,anim:6})
				}
			})
		});		
	});
	/*登录-回车绑定*/
	var login_click =function(){
		$("form#login:eq(0)").on('keydown',function() {
			if (event.keyCode == "13"){
				$('form#login:eq(0) button#login:eq(0)').click();
			}
		});
	}
	login_click();
	/*登录|注册->设置eq(0)防止多个登录动作时，serialize收集额外的表单导致错误*/
	$(".modal-body,form#login:eq(0)").on('click','button#login',function(){
		userdata=$("form#login:eq(0)").serialize();
		action=$(this).attr('action');
		if (!$('#username').val()) {layer.tips('不能为空', '#username', {tips: [1, '#0FA6D8']}); return;}
		if (!$('#password').val()) {layer.tips('不能为空', '#password', {tips: [1, '#0FA6D8']}); return;}
			$.ajax({
			url:'/'+action,
			type:'post',
			data:userdata,
			dataType :'json',
			timeout:'15000',
			async:true,
				success:function(data){
						layer.alert(
							data.msg,
							{
								closeBtn: 0,
								title:''
								,btn: ['确定']
								,yes:function(){
									layer.closeAll();
									if (data.code && action!='reg'){
										$('#myModal').modal('hide');
										console.log(location.pathname)
										location.reload();
									}
								}
							}
						);
						
				},
				error:function(xhr){
					layer.msg('错误：'+xhr.status+' '+xhr.statusText,{time: 3000,anim:6})
				}
			})
			
	});

	/*按钮文字切换*/
	$('body').on('click','[data-loading-text]',function(){
		$(this).button('loading').delay(1000).queue(function() {
			$(this).button('reset');
			$(this).dequeue();
		});
	});
	/*密码输入框显示隐藏*/
	$(".modal-body,form").on('click','#toggle-password',function(){
		if ($(this).prev().attr('type')=="password"){
			$(this).prev().attr('type','text');
			$(this).children().attr('class','glyphicon glyphicon-eye-close')
		}else{
			$(this).prev().attr('type','password');
			$(this).children().attr('class','glyphicon glyphicon-eye-open')
		}
	});
	$("[data-toggle='tooltip']").tooltip();
	/*模态框监测关闭后清除内容*/
	$('#myModal').on('hide.bs.modal', function () {
		$('.modal-title').html('');
		$('.modal-body').html('');
	})
	/*qq头像获取 同类插件复用*/
	$("#trash,#btnr").hide();//清除输入框按钮隐藏
	$("#input_data").bind("input propertychange keyup paste",function(event){
		if ($("#input_data").val().length>0){
			$("#trash,#btnr").fadeIn("3000");
		}else{
			$("#trash,#btnr").fadeOut("2000");
		}
	});
	/*输入框内容填充*/
	$("a#test_data").click(function(){
		$("#input_data").val($(this).text()).focus().trigger('input');//填充内容、聚焦、触发输入
		$("#trash,#btnr").fadeIn("3000");
	});
	/*输入框内容清除*/
	$("#trash").click(function(){
		$("#input_data").val("");
		$("#trash,#btnr").fadeOut("2000");
	});
	setInterval(clock,1000);
});